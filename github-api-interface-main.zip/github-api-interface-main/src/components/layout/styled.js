import styled from "styled-components";

export const WrapperLayout = styled.section`
  margin: 16px;
`;
